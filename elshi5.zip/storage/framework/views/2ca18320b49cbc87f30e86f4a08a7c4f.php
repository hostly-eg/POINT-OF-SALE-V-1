

<?php $__env->startSection('content'); ?>
<div class="container text-end">
    <h2>تعديل القسم</h2>

    <form method="POST" action="<?php echo e(route('categories.update', $category->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="name" class="form-label">اسم القسم</label>
            <input type="text" name="name" id="name" class="form-control" value="<?php echo e($category->name); ?>" required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="btn btn-primary">تحديث</button>
        <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary">رجوع</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\elshi5\resources\views/categories/edit.blade.php ENDPATH**/ ?>