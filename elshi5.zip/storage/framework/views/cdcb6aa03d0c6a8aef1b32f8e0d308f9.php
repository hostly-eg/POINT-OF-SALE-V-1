

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="mb-4">حركة المخزون</h3>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    
    <div class="mb-3 d-flex gap-2">
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#inModal">➕ إضافة كمية</button>
        <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#outModal">➖ سحب كمية</button>
    </div>

    
    <div class="card">
        <div class="card-body">
            <table class="table table-bordered text-center">
                <thead class="table-dark">
                    <tr>
                        <th>المنتج</th>
                        <th>النوع</th>
                        <th>الكمية</th>
                        <th>ملاحظات</th>
                        <th>التاريخ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($movement->product->name ?? '—'); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($movement->type == 'in' ? 'success' : 'danger'); ?>">
                                    <?php echo e($movement->type == 'in' ? 'دخول' : 'خروج'); ?>

                                </span>
                            </td>
                            <td><?php echo e($movement->quantity); ?></td>
                            <td><?php echo e($movement->note ?? '-'); ?></td>
                            <td><?php echo e($movement->created_at->format('Y-m-d H:i')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5">لا توجد حركات حالياً.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="modal fade" id="inModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('stock.in')); ?>">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header"><h5 class="modal-title">إضافة للمخزون</h5></div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label>المنتج</label>
                        <select name="product_id" class="form-select" required>
                            <option value="">اختر المنتج</option>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>الكمية</label>
                        <input type="number" name="quantity" class="form-control" min="1" required>
                    </div>
                    <div class="mb-3">
                        <label>ملاحظات</label>
                        <textarea name="note" class="form-control"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">حفظ</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                </div>
            </div>
        </form>
    </div>
</div>


<div class="modal fade" id="outModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('stock.out')); ?>">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header"><h5 class="modal-title">سحب من المخزون</h5></div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label>المنتج</label>
                        <select name="product_id" class="form-select" required>
                            <option value="">اختر المنتج</option>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>الكمية</label>
                        <input type="number" name="quantity" class="form-control" min="1" required>
                    </div>
                    <div class="mb-3">
                        <label>ملاحظات</label>
                        <textarea name="note" class="form-control"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">سحب</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\elshi5\resources\views/stock/index.blade.php ENDPATH**/ ?>