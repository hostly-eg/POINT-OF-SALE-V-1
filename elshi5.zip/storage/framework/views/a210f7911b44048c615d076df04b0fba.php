

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- نموذج إضافة / تعديل -->
        <div class="card mb-4">
            <div class="card-header"><?php echo e(isset($editExpense) ? 'تعديل النفقة' : 'إضافة نفقة جديدة'); ?></div>
            <div class="card-body">
                <form
                    action="<?php echo e(isset($editExpense) ? route('expenses.update', $editExpense->id) : route('expenses.store')); ?>"
                    method="POST">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($editExpense)): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php endif; ?>

                    <div class="mb-3">
                        <label for="description" class="form-label">الوصف</label>
                        <input type="text" class="form-control" name="description" id="description"
                            value="<?php echo e(old('description', $editExpense->description ?? '')); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="amount" class="form-label">المبلغ</label>
                        <input type="number" step="0.01" class="form-control" name="amount" id="amount"
                            value="<?php echo e(old('amount', $editExpense->amount ?? '')); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="date" class="form-label">التاريخ</label>
                        <input type="date" class="form-control" name="expense_date" id="date" 
                            value="<?php echo e(old('expense_date', isset($editExpense) && $editExpense->expense_date ? \Carbon\Carbon::parse($editExpense->expense_date)->format('Y-m-d') : now()->format('Y-m-d'))); ?>">

                    </div>

                    <button type="submit" class="btn btn-primary">
                        <?php echo e(isset($editExpense) ? 'تحديث' : 'إضافة'); ?>

                    </button>

                    <?php if(isset($editExpense)): ?>
                        <a href="<?php echo e(route('expenses.index')); ?>" class="btn btn-secondary">إلغاء</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <!-- جدول النفقات -->
        <div class="card">
            <div class="card-header">قائمة النفقات</div>
            <div class="card-body">
                <table class="table table-bordered text-center">
                    <thead>
                        <tr>
                            <th>الوصف</th>
                            <th>المبلغ</th>
                            <th>التاريخ</th>
                            <th>العمليات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($expense->description); ?></td>
                                <td><?php echo e(number_format($expense->amount, 2)); ?> ج</td>
                                <td><?php echo e(\Carbon\Carbon::parse($expense->expense_date)->format('Y-m-d')); ?></td>
                                <td>
                                    <a href="<?php echo e(route('expenses.edit', $expense->id)); ?>"
                                        class="btn btn-sm btn-warning">تعديل</a>
                                    <form action="<?php echo e(route('expenses.destroy', $expense->id)); ?>" method="POST"
                                        style="display:inline-block;" onsubmit="return confirm('هل أنت متأكد من الحذف؟');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-danger">حذف</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4">لا توجد نفقات مسجلة.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\elshi5\resources\views/expenses/index.blade.php ENDPATH**/ ?>