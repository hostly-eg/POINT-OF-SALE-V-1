

<?php $__env->startSection('content'); ?>
<div class="container text-end">
    <h2>كل المنتجات</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary mb-3">إضافة منتج جديد</a>

    <table class="table table-bordered table-striped text-center">
        <thead>
            <tr>
                <th>الصورة</th>
                <th>الاسم</th>
                <th>القسم</th>
                <th>البراند</th>
                <th>السعر</th>
                <th>الربح (%)</th>
                <th>الكمية</th>
                <th>الإجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <?php if($product->image): ?>
                        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" width="50">
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->category->name ?? '-'); ?></td>
                <td><?php echo e($product->brand->name ?? '-'); ?></td>
                <td><?php echo e($product->price); ?> ج.م</td>
                <td><?php echo e($product->profit_margin); ?>%</td>
                <td><?php echo e($product->quantity); ?></td>
                <td>
                    <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-sm btn-warning">تعديل</a>
                    <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST"
                        style="display:inline-block">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('حذف المنتج؟')">حذف</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="8">لا توجد منتجات حالياً</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\elshi5\resources\views/products/index.blade.php ENDPATH**/ ?>