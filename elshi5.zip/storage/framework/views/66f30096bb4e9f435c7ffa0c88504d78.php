

<?php $__env->startSection('content'); ?>
<div class="container text-end">
    <h2>كل البراندات</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('brands.create')); ?>" class="btn btn-primary mb-3">إضافة براند جديد</a>

    <table class="table table-bordered text-center">
        <thead>
            <tr>
                <th>#</th>
                <th>اسم البراند</th>
                <th>الإجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($brand->name); ?></td>
                <td>
                    <a href="<?php echo e(route('brands.edit', $brand->id)); ?>" class="btn btn-sm btn-warning">تعديل</a>
                    <form action="<?php echo e(route('brands.destroy', $brand->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('حذف البراند؟')">حذف</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="3">لا توجد بيانات</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\elshi5\resources\views/brands/index.blade.php ENDPATH**/ ?>