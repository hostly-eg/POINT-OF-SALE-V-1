

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="mb-4">🧾 صفحة الجرد</h2>

        <ul class="nav nav-tabs" id="auditTabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="products-tab" data-bs-toggle="tab" href="#products" role="tab">المنتجات</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="sales-tab" data-bs-toggle="tab" href="#sales" role="tab">المبيعات</a>
            </li>
        </ul>

        <div class="tab-content mt-4" id="auditTabsContent">
            <!-- 🟦 المنتجات -->
            <div class="tab-pane fade show active" id="products" role="tabpanel">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>المنتج</th>
                            <th>الكمية القديمة</th>
                            <th>الكمية الجديدة</th>
                            <th>الفرق</th>
                            <th>نوع التغيير</th>
                            <th>الوقت</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $audits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($audit->product->name ?? 'غير موجود'); ?></td>
                                <td><?php echo e($audit->old_quantity); ?></td>
                                <td><?php echo e($audit->new_quantity); ?></td>
                                <td><?php echo e($audit->difference); ?></td>
                                <td><?php echo e($audit->change_type); ?></td>
                                <td><?php echo e($audit->created_at->format('Y-m-d H:i')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- 🟨 المبيعات -->
            <div class="tab-pane fade" id="sales" role="tabpanel">
                <div class="accordion" id="salesAccordion">
                    <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="heading<?php echo e($sale->id); ?>">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapse<?php echo e($sale->id); ?>" aria-expanded="false"
                                    aria-controls="collapse<?php echo e($sale->id); ?>">
                                    فاتورة رقم <?php echo e($sale->id); ?> -
                                    <?php echo e(\Carbon\Carbon::parse($sale->created_at)->format('Y-m-d H:i')); ?>

                                </button>
                            </h2>
                            <div id="collapse<?php echo e($sale->id); ?>" class="accordion-collapse collapse"
                                aria-labelledby="heading<?php echo e($sale->id); ?>" data-bs-parent="#salesAccordion">
                                <div class="accordion-body">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>المنتج</th>
                                                <th>الكمية</th>
                                                <th>السعر</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $sale->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($item->product->name ?? 'غير موجود'); ?></td>
                                                    <td><?php echo e($item->quantity); ?></td>
                                                    <td><?php echo e($item->price); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\elshi5\resources\views/seals/index.blade.php ENDPATH**/ ?>